package com.wavesurvival.mod.wave;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.wavesurvival.mod.core.WaveSurvivalMod;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Mod.EventBusSubscriber(modid = WaveSurvivalMod.MOD_ID)
public class CoinCapability {

    public static final Capability<PlayerCoinData> COIN_DATA = CapabilityManager.get(new CapabilityToken<>() {});
    private static final ResourceLocation CAP_KEY = new ResourceLocation(WaveSurvivalMod.MOD_ID, "coin_data");

    @SubscribeEvent
    public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            event.addCapability(CAP_KEY, new Provider());
        }
    }

    public static class Provider implements ICapabilityProvider, net.minecraftforge.common.util.INBTSerializable<CompoundTag> {
        private PlayerCoinData data = null;
        private final LazyOptional<PlayerCoinData> optional = LazyOptional.of(this::getData);

        private PlayerCoinData getData() {
            if (data == null) data = new PlayerCoinData();
            return data;
        }

        @Override
        public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
            return COIN_DATA.orEmpty(cap, optional);
        }

        @Override
        public CompoundTag serializeNBT() { return getData().serializeNBT(); }

        @Override
        public void deserializeNBT(CompoundTag nbt) { getData().deserializeNBT(nbt); }
    }
}
