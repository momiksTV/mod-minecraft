package com.wavesurvival.mod.events;

import com.wavesurvival.mod.core.WaveSurvivalMod;
import com.wavesurvival.mod.gui.ShopMenuType;
import com.wavesurvival.mod.network.NetworkHandler;
import com.wavesurvival.mod.network.packets.SyncCoinPacket;
import com.wavesurvival.mod.wave.PlayerCoinData;
import com.wavesurvival.mod.wave.WaveManager;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.Random;

@Mod.EventBusSubscriber(modid = WaveSurvivalMod.MOD_ID)
public class ForgeEventHandler {

    private static final Random RANDOM = new Random();
    private static int serverTickCounter = 0;

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        serverTickCounter++;
        // Only tick wave manager every 20 ticks (1 second) to save performance
        if (serverTickCounter % 20 != 0) return;

        for (ServerLevel level : event.getServer().getAllLevels()) {
            if (level.dimension() == ServerLevel.OVERWORLD) {
                WaveManager wm = WaveManager.get(level);
                wm.tick(level);
            }
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof Monster mob)) return;
        if (!mob.getPersistentData().contains("wave_monster")) return;

        // Award coins to nearby players
        ServerLevel level = (ServerLevel) mob.level();
        int wave = mob.getPersistentData().getInt("wave_number");
        int coinsReward = calculateCoins(mob, wave);

        for (Player player : level.players()) {
            if (player.distanceTo(mob) <= 32) {
                PlayerCoinData coinData = PlayerCoinData.get(player);
                coinData.addCoins(coinsReward);

                // Notify client of new balance
                if (player instanceof ServerPlayer sp) {
                    NetworkHandler.CHANNEL.send(
                            PacketDistributor.PLAYER.with(() -> sp),
                            new SyncCoinPacket(coinData.getCoins())
                    );
                    sp.sendSystemMessage(Component.literal("§6+" + coinsReward + " монет за убийство!"), true);
                }
            }
        }

        // Update wave manager
        WaveManager wm = WaveManager.get(level);
        wm.decrementMonsters();
        wm.broadcastSync(level);
    }

    @SubscribeEvent
    public static void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer sp)) return;

        ServerLevel level = sp.getLevel() instanceof ServerLevel sl ? sl : null;
        if (level == null) return;

        // Give starter kit
        if (!sp.getPersistentData().getBoolean(WaveSurvivalMod.MOD_ID + "_starter_given")) {
            sp.getInventory().add(new ItemStack(Items.WOODEN_SWORD));
            sp.getInventory().add(new ItemStack(Items.BREAD, 10));
            sp.getPersistentData().putBoolean(WaveSurvivalMod.MOD_ID + "_starter_given", true);
        }

        // Sync wave data to new player
        WaveManager wm = WaveManager.get(level);
        wm.broadcastSync(level);

        // Start game if not started (first player)
        if (!wm.isGameStarted()) {
            wm.startGame(level);
        }

        // Sync coins
        PlayerCoinData coinData = PlayerCoinData.get(sp);
        NetworkHandler.CHANNEL.send(
                PacketDistributor.PLAYER.with(() -> sp),
                new SyncCoinPacket(coinData.getCoins())
        );
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        // Copy coin data on death/dimension change
        if (!event.isWasDeath()) return;
        event.getOriginal().reviveCaps();
        PlayerCoinData original = PlayerCoinData.get(event.getOriginal());
        PlayerCoinData newData = PlayerCoinData.get(event.getEntity());
        // Keep 50% of coins on death
        newData.addCoins(original.getCoins() / 2);
        event.getOriginal().invalidateCaps();
    }

    private static int calculateCoins(Monster mob, int wave) {
        // Base reward scaled by wave + mob type rarity
        int base = 5 + (wave * 2);
        String entityName = mob.getType().toString().toLowerCase();
        if (entityName.contains("ravager") || entityName.contains("evoker") || entityName.contains("wither")) {
            base *= 5;
        } else if (entityName.contains("witch") || entityName.contains("vindicator") || entityName.contains("pillager")) {
            base *= 2;
        }
        // Random bonus ±20%
        double mult = 0.8 + RANDOM.nextDouble() * 0.4;
        return Math.max(1, (int)(base * mult));
    }
}
