package com.wavesurvival.mod.core;

import com.wavesurvival.mod.events.ForgeEventHandler;
import com.wavesurvival.mod.gui.ShopMenuType;
import com.wavesurvival.mod.items.CoinItem;
import com.wavesurvival.mod.network.NetworkHandler;
import com.wavesurvival.mod.wave.WaveManager;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(WaveSurvivalMod.MOD_ID)
public class WaveSurvivalMod {

    public static final String MOD_ID = "wavesurvival";

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);

    public static final RegistryObject<Item> COIN =
            ITEMS.register("coin", () -> new CoinItem(new Item.Properties().stacksTo(9999)));

    public WaveSurvivalMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ITEMS.register(modEventBus);
        ShopMenuType.MENUS.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::addCreative);

        MinecraftForge.EVENT_BUS.register(new ForgeEventHandler());
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        NetworkHandler.register();
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(COIN);
        }
    }
}
