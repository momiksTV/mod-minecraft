package com.wavesurvival.mod.wave;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.AutoRegisterCapability;

@AutoRegisterCapability
public class PlayerCoinData {

    private int coins = 0;

    public int getCoins() { return coins; }

    public void addCoins(int amount) {
        coins = Math.max(0, coins + amount);
    }

    public boolean spendCoins(int amount) {
        if (coins >= amount) {
            coins -= amount;
            return true;
        }
        return false;
    }

    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("coins", coins);
        return tag;
    }

    public void deserializeNBT(CompoundTag tag) {
        coins = tag.getInt("coins");
    }

    public static PlayerCoinData get(Player player) {
        return player.getCapability(CoinCapability.COIN_DATA).orElse(new PlayerCoinData());
    }
}
