package com.wavesurvival.mod.core;

import com.wavesurvival.mod.gui.ShopMenu;
import com.wavesurvival.mod.gui.ShopMenuType;
import com.wavesurvival.mod.gui.ShopScreen;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = WaveSurvivalMod.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientSetup {

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            MenuScreens.register(ShopMenuType.SHOP_MENU.get(), ShopScreen::new);
        });
    }
}
