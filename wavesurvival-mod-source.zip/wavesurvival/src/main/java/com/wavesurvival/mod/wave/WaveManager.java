package com.wavesurvival.mod.wave;

import com.wavesurvival.mod.core.WaveSurvivalMod;
import com.wavesurvival.mod.network.NetworkHandler;
import com.wavesurvival.mod.network.packets.SyncWaveDataPacket;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class WaveManager extends SavedData {

    private static final String DATA_NAME = WaveSurvivalMod.MOD_ID + "_wave_data";
    private static final Random RANDOM = new Random();

    private int currentWave = 0;
    private boolean waveActive = false;
    private int monstersRemaining = 0;
    private int ticksUntilNextWave = 200; // 10 seconds after death of last mob
    private boolean gameStarted = false;

    public static WaveManager get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(
                WaveManager::load,
                WaveManager::new,
                DATA_NAME
        );
    }

    public static WaveManager load(CompoundTag tag) {
        WaveManager manager = new WaveManager();
        manager.currentWave = tag.getInt("currentWave");
        manager.waveActive = tag.getBoolean("waveActive");
        manager.monstersRemaining = tag.getInt("monstersRemaining");
        manager.ticksUntilNextWave = tag.getInt("ticksUntilNextWave");
        manager.gameStarted = tag.getBoolean("gameStarted");
        return manager;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putInt("currentWave", currentWave);
        tag.putBoolean("waveActive", waveActive);
        tag.putInt("monstersRemaining", monstersRemaining);
        tag.putInt("ticksUntilNextWave", ticksUntilNextWave);
        tag.putBoolean("gameStarted", gameStarted);
        return tag;
    }

    public void tick(ServerLevel level) {
        if (!gameStarted) return;

        if (waveActive) {
            // Count alive monsters tagged with our mod
            long alive = level.getEntities(null, e ->
                    e instanceof Monster && e.getPersistentData().contains("wave_monster")
            ).stream().count();

            if (alive == 0) {
                waveActive = false;
                monstersRemaining = 0;
                ticksUntilNextWave = 300; // 15 sec break
                broadcastSync(level);
                sendTitleToAll(level, "§a✔ Волна " + currentWave + " завершена!", "§eСледующая волна через 15 секунд...");
            }
        } else {
            if (ticksUntilNextWave > 0) {
                ticksUntilNextWave--;
            } else {
                startNextWave(level);
            }
        }
    }

    public void startGame(ServerLevel level) {
        if (gameStarted) return;
        gameStarted = true;
        currentWave = 0;
        ticksUntilNextWave = 100;
        setDirty();
        sendTitleToAll(level, "§6⚔ Wave Survival", "§eПриготовьтесь! Первая волна скоро начнётся!");
    }

    private void startNextWave(ServerLevel level) {
        currentWave++;
        waveActive = true;

        List<ServerPlayer> players = level.getServer().getPlayerList().getPlayers();
        if (players.isEmpty()) return;

        int baseCount = 5 + (currentWave * 3);
        monstersRemaining = baseCount;

        for (int i = 0; i < baseCount; i++) {
            // Pick random player as spawn anchor
            ServerPlayer target = players.get(RANDOM.nextInt(players.size()));
            Vec3 pos = getSpawnPos(target);
            spawnMonster(level, pos, currentWave);
        }

        broadcastSync(level);
        sendTitleToAll(level, "§c⚠ Волна " + currentWave + "!", "§fМонстров: §c" + baseCount);
        setDirty();
    }

    private Vec3 getSpawnPos(ServerPlayer player) {
        double angle = RANDOM.nextDouble() * Math.PI * 2;
        double dist = 20 + RANDOM.nextDouble() * 10;
        double x = player.getX() + Math.cos(angle) * dist;
        double z = player.getZ() + Math.sin(angle) * dist;
        double y = player.getY();
        return new Vec3(x, y, z);
    }

    private void spawnMonster(ServerLevel level, Vec3 pos, int wave) {
        Monster mob = pickMonsterType(level, wave);
        if (mob == null) return;

        mob.setPos(pos.x, pos.y, pos.z);
        mob.getPersistentData().putBoolean("wave_monster", true);
        mob.getPersistentData().putInt("wave_number", wave);

        // Apply difficulty scaling
        applyWaveScaling(mob, wave);

        level.addFreshEntity(mob);
    }

    private Monster pickMonsterType(ServerLevel level, int wave) {
        List<Monster> pool = new ArrayList<>();

        // Basic mobs always available
        pool.add(new Zombie(net.minecraft.world.entity.EntityType.ZOMBIE, level));
        pool.add(new Skeleton(net.minecraft.world.entity.EntityType.SKELETON, level));

        if (wave >= 3) {
            pool.add(new Spider(net.minecraft.world.entity.EntityType.SPIDER, level));
            pool.add(new Husk(net.minecraft.world.entity.EntityType.HUSK, level));
        }
        if (wave >= 5) {
            pool.add(new Creeper(net.minecraft.world.entity.EntityType.CREEPER, level));
            pool.add(new Stray(net.minecraft.world.entity.EntityType.STRAY, level));
        }
        if (wave >= 8) {
            pool.add(new Witch(net.minecraft.world.entity.EntityType.WITCH, level));
            pool.add(new Vindicator(net.minecraft.world.entity.EntityType.VINDICATOR, level));
        }
        if (wave >= 12) {
            pool.add(new Pillager(net.minecraft.world.entity.EntityType.PILLAGER, level));
            pool.add(new Piglin(net.minecraft.world.entity.EntityType.PIGLIN, level));
        }
        if (wave >= 15) {
            pool.add(new Ravager(net.minecraft.world.entity.EntityType.RAVAGER, level));
            pool.add(new Evoker(net.minecraft.world.entity.EntityType.EVOKER, level));
        }
        if (wave >= 20) {
            pool.add(new Wither(net.minecraft.world.entity.EntityType.WITHER, level));
        }

        return pool.get(RANDOM.nextInt(pool.size()));
    }

    private void applyWaveScaling(Monster mob, int wave) {
        // Health scaling
        float healthBonus = wave * 4.0f;
        mob.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH)
                .setBaseValue(mob.getMaxHealth() + healthBonus);
        mob.setHealth(mob.getMaxHealth());

        // Speed scaling (capped)
        double speedBonus = Math.min(wave * 0.01, 0.15);
        mob.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED)
                .setBaseValue(0.23 + speedBonus);

        // Damage scaling
        var dmgAttr = mob.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE);
        if (dmgAttr != null) {
            dmgAttr.setBaseValue(dmgAttr.getBaseValue() + wave * 0.5);
        }

        // Effects on higher waves
        if (wave >= 5 && RANDOM.nextFloat() < 0.4f) {
            mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, Integer.MAX_VALUE, Math.min(wave / 5, 2)));
        }
        if (wave >= 8 && RANDOM.nextFloat() < 0.3f) {
            mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, Integer.MAX_VALUE, Math.min(wave / 8, 2)));
        }
        if (wave >= 10 && RANDOM.nextFloat() < 0.25f) {
            mob.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, Integer.MAX_VALUE, 0));
        }
        if (wave >= 12 && RANDOM.nextFloat() < 0.2f) {
            mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, Integer.MAX_VALUE, 1));
        }

        // Armor on higher waves
        if (wave >= 6 && RANDOM.nextFloat() < 0.35f) {
            equipArmor(mob, wave);
        }

        // Weapon enchantments
        if (wave >= 7 && RANDOM.nextFloat() < 0.3f) {
            enchantWeapon(mob, wave);
        }
    }

    private void equipArmor(Monster mob, int wave) {
        ArmorTier tier = wave >= 15 ? ArmorTier.DIAMOND :
                wave >= 10 ? ArmorTier.IRON :
                wave >= 6  ? ArmorTier.CHAINMAIL : ArmorTier.LEATHER;

        ItemStack helmet = new ItemStack(tier.helmet);
        ItemStack chestplate = new ItemStack(tier.chestplate);
        ItemStack leggings = new ItemStack(tier.leggings);
        ItemStack boots = new ItemStack(tier.boots);

        if (wave >= 12) {
            int prot = Math.min(wave / 4, 4);
            helmet.enchant(Enchantments.ALL_DAMAGE_PROTECTION, prot);
            chestplate.enchant(Enchantments.ALL_DAMAGE_PROTECTION, prot);
        }

        mob.setItemSlot(EquipmentSlot.HEAD, helmet);
        mob.setItemSlot(EquipmentSlot.CHEST, chestplate);
        mob.setItemSlot(EquipmentSlot.LEGS, leggings);
        mob.setItemSlot(EquipmentSlot.FEET, boots);
    }

    private void enchantWeapon(Monster mob, int wave) {
        ItemStack weapon = mob.getMainHandItem();
        if (weapon.isEmpty()) {
            weapon = new ItemStack(wave >= 10 ? Items.IRON_SWORD : Items.STONE_SWORD);
        }
        int sharpness = Math.min(wave / 5, 5);
        if (sharpness > 0) weapon.enchant(Enchantments.SHARPNESS, sharpness);
        if (wave >= 10) weapon.enchant(Enchantments.FIRE_ASPECT, 1);
        mob.setItemSlot(EquipmentSlot.MAINHAND, weapon);
    }

    private void sendTitleToAll(ServerLevel level, String title, String subtitle) {
        for (ServerPlayer p : level.getServer().getPlayerList().getPlayers()) {
            p.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket(
                    net.minecraft.network.chat.Component.literal(title)));
            p.connection.send(new net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket(
                    net.minecraft.network.chat.Component.literal(subtitle)));
            p.connection.send(new net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket(10, 60, 20));
        }
    }

    public void broadcastSync(ServerLevel level) {
        SyncWaveDataPacket packet = new SyncWaveDataPacket(currentWave, waveActive, ticksUntilNextWave);
        NetworkHandler.CHANNEL.send(PacketDistributor.ALL.noArg(), packet);
    }

    // Getters
    public int getCurrentWave() { return currentWave; }
    public boolean isWaveActive() { return waveActive; }
    public int getMonstersRemaining() { return monstersRemaining; }
    public int getTicksUntilNextWave() { return ticksUntilNextWave; }
    public boolean isGameStarted() { return gameStarted; }

    public void decrementMonsters() {
        if (monstersRemaining > 0) monstersRemaining--;
        setDirty();
    }

    // Armor tier helper
    private enum ArmorTier {
        LEATHER(Items.LEATHER_HELMET, Items.LEATHER_CHESTPLATE, Items.LEATHER_LEGGINGS, Items.LEATHER_BOOTS),
        CHAINMAIL(Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE, Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS),
        IRON(Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS),
        DIAMOND(Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS);

        final net.minecraft.world.item.Item helmet, chestplate, leggings, boots;

        ArmorTier(net.minecraft.world.item.Item h, net.minecraft.world.item.Item c,
                  net.minecraft.world.item.Item l, net.minecraft.world.item.Item b) {
            helmet = h; chestplate = c; leggings = l; boots = b;
        }
    }
}
